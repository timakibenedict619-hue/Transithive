import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig={
  apiKey:"AIzaSyC1rb8p4KsKaxQK_QVtjWbFE5IStV1F5CI",
  authDomain:"swifttrans-logistics.firebaseapp.com",
  projectId:"swifttrans-logistics",
  storageBucket:"swifttrans-logistics.firebasestorage.app",
  messagingSenderId:"336087148680",
  appId:"1:336087148680:web:d3fb690dd18d2337ca973d"
};

export const app=initializeApp(firebaseConfig);
export const db=getFirestore(app);
